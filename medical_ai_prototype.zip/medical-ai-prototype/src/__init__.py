"""Top-level package for the medical AI prototype.

This file allows the ``src`` directory to be treated as a Python package.
"""

__all__ = []