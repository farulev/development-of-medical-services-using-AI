"""Baseline CNN architecture for the medical AI prototype.

This module defines a simple convolutional neural network suitable for
binary classification of small images.  The architecture consists of
a few convolutional layers with batch normalisation and max pooling,
followed by fully connected layers.  It accepts configurable input
channels and outputs logits for a configurable number of classes.

This baseline is intentionally kept simple for demonstration purposes
and can be replaced or extended with more advanced models (e.g.
ResNet, EfficientNet) in future iterations.
"""

from __future__ import annotations

import torch
from torch import nn


class CNNBaseline(nn.Module):
    """A small convolutional neural network for binary classification."""

    def __init__(self, num_classes: int = 2, input_channels: int = 3) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(input_channels, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        # After 3 poolings with stride 2, the spatial dimension is reduced by 8
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 28 * 28, 128),  # assuming input 224x224
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.classifier(x)
        return x
