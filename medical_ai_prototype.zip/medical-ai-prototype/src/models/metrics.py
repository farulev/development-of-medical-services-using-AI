"""Metric computation utilities for classification tasks.

This module wraps common metric functions from scikit‑learn and handles
edge cases where metrics are undefined.  All functions accept lists
or tensors of ground truth labels and predicted labels or scores and
return floats.
"""

from __future__ import annotations

from typing import Iterable, List, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_auc_score,
)


def compute_basic_metrics(y_true: Iterable[int], y_pred: Iterable[int]) -> Tuple[float, float, float, float]:
    """Compute accuracy, precision, recall and F1 score.

    For binary classification precision and recall are computed for the
    positive class using macro averaging.
    """
    y_true = np.asarray(list(y_true))
    y_pred = np.asarray(list(y_pred))
    acc = float(accuracy_score(y_true, y_pred))
    # Use macro average to handle class imbalance gracefully
    prec = float(precision_score(y_true, y_pred, average="binary", zero_division=0))
    rec = float(recall_score(y_true, y_pred, average="binary", zero_division=0))
    f1 = float(f1_score(y_true, y_pred, average="binary", zero_division=0))
    return acc, prec, rec, f1


def compute_confusion(y_true: Iterable[int], y_pred: Iterable[int]) -> np.ndarray:
    """Return the confusion matrix."""
    y_true = np.asarray(list(y_true))
    y_pred = np.asarray(list(y_pred))
    return confusion_matrix(y_true, y_pred)


def compute_roc_auc(y_true: Iterable[int], y_scores: Iterable[float]) -> float | None:
    """Compute ROC‑AUC for binary classification.

    Returns ``None`` if the score cannot be computed (e.g. only one
    class present).
    """
    y_true = np.asarray(list(y_true))
    y_scores = np.asarray(list(y_scores))
    try:
        return float(roc_auc_score(y_true, y_scores))
    except ValueError:
        return None
