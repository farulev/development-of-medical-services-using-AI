"""Training script for the medical AI prototype.

This module defines a command‑line entry point that reads a YAML
configuration, constructs datasets and data loaders, instantiates
the CNN baseline model and trains it with early stopping.  The best
model checkpoint is saved to the configured directory.  Metrics are
printed to the console during training.

Usage:

    python scripts/run_training.py --config configs/train.yaml

"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Dict

import torch
from torch import nn
from torch.optim import Adam

from ..data.loaders import create_dataloaders
from ..models.cnn_baseline import CNNBaseline
from ..utils.config import load_config
from ..utils.logging import get_logger
from ..utils.seed import set_seed


def train_model(config: Dict[str, Any]) -> Path:
    """Train the model according to the provided configuration.

    Args:
        config: Parsed configuration dictionary.

    Returns:
        Path to the best checkpoint file.
    """
    logger = get_logger(__name__)

    # Set reproducibility
    set_seed(42)

    # Create dataloaders
    train_loader, val_loader, _ = create_dataloaders(config)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    num_classes = len(train_loader.dataset.label_to_index)
    model = CNNBaseline(num_classes=num_classes, input_channels=3).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = Adam(
        model.parameters(),
        lr=float(config["training"].get("learning_rate", 0.001)),
        weight_decay=float(config["training"].get("weight_decay", 0.0)),
    )

    num_epochs = int(config["training"].get("num_epochs", 10))
    patience = int(config["training"].get("early_stopping_patience", 3))
    checkpoint_dir = Path(config["training"].get("checkpoint_dir", "outputs"))
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    best_val_loss = float("inf")
    epochs_no_improve = 0
    best_checkpoint_path = checkpoint_dir / "best_model.pth"

    logger.info(f"Starting training for {num_epochs} epochs on {device}…")

    for epoch in range(1, num_epochs + 1):
        model.train()
        running_loss = 0.0
        for batch_idx, (inputs, targets) in enumerate(train_loader, start=1):
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            log_interval = int(config.get("logging", {}).get("log_interval", 10))
            if batch_idx % max(1, log_interval) == 0:
                avg_loss = running_loss / log_interval
                logger.info(
                    f"Epoch {epoch} [{batch_idx * len(inputs)}/{len(train_loader.dataset)}] "
                    f"Loss: {avg_loss:.4f}"
                )
                running_loss = 0.0

        # Validation step
        val_loss = 0.0
        model.eval()
        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                val_loss += loss.item()
        val_loss /= max(1, len(val_loader))
        logger.info(f"Epoch {epoch}: Validation Loss: {val_loss:.4f}")

        # Check for improvement
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0
            # Save the best model
            torch.save(model.state_dict(), best_checkpoint_path)
            logger.info(f"New best model saved to {best_checkpoint_path}")
        else:
            epochs_no_improve += 1
            logger.info(
                f"No improvement. Patience {epochs_no_improve}/{patience}"
            )
            if epochs_no_improve >= patience:
                logger.info(
                    f"Early stopping triggered after {epoch} epochs."
                )
                break

    return best_checkpoint_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the CNN model on the dataset.")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/train.yaml",
        help="Path to the YAML configuration file.",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    checkpoint_path = train_model(config)
    print(f"Training completed. Best model saved at: {checkpoint_path}")


if __name__ == "__main__":
    main()
