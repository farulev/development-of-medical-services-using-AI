"""Inference utilities and CLI for the medical AI prototype.

This module provides a function to load a trained model from a
checkpoint and perform inference on a single image.  It can be used
programmatically or run as a standalone script.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

import torch
from PIL import Image

from ..data.transforms import get_transforms
from ..models.cnn_baseline import CNNBaseline
from ..utils.config import load_config


def load_trained_model(checkpoint_path: Path, num_classes: int = 2) -> CNNBaseline:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNNBaseline(num_classes=num_classes)
    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    model.to(device)
    model.eval()
    return model


def predict_image(
    image_path: Path, model: CNNBaseline, input_size: int = 224
) -> Dict[str, Any]:
    """Run the model on a single image and return prediction and confidence.

    Args:
        image_path: Path to the image file.
        model: Loaded model in eval mode.
        input_size: Image size to resize to.

    Returns:
        A dictionary with predicted class index, confidence and disclaimer.
    """
    # Use transforms appropriate for validation/test
    transform = get_transforms("test", input_size=input_size)
    with Image.open(image_path) as img:
        img = img.convert("RGB")
    tensor = transform(img).unsqueeze(0)
    device = next(model.parameters()).device
    tensor = tensor.to(device)
    with torch.no_grad():
        logits = model(tensor)
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
    pred_idx = int(probs.argmax())
    confidence = float(probs[pred_idx])
    return {
        "prediction_index": pred_idx,
        "confidence": confidence,
        "disclaimer": "This prediction is for research use only and must not be used for clinical decision‑making.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run inference on a single image using a trained model.")
    parser.add_argument("--image", type=str, required=True, help="Path to the image file.")
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to the model checkpoint (*.pth).",
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/inference.yaml",
        help="Path to inference configuration file (for input_size etc.).",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    input_size = int(config.get("model", {}).get("input_size", 224))
    num_classes = 2  # For prototype we assume binary classification; can be extended
    model = load_trained_model(Path(args.checkpoint), num_classes=num_classes)
    result = predict_image(Path(args.image), model, input_size)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
