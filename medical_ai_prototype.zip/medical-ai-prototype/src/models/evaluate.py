"""Evaluation script for the medical AI prototype.

This module loads a trained model checkpoint and computes evaluation
metrics on the validation or test dataset.  It prints accuracy,
precision, recall, F1‑score, ROC‑AUC (if computable) and the confusion
matrix.  It is intended to be invoked via the command line.

Usage:

    python -m src.models.evaluate --config configs/train.yaml --checkpoint outputs/best_model.pth --split test
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict

import torch

from ..data.loaders import create_dataloaders
from ..models.cnn_baseline import CNNBaseline
from ..models.metrics import (
    compute_basic_metrics,
    compute_confusion,
    compute_roc_auc,
)
from ..utils.config import load_config


def evaluate_model(config: Dict[str, Any], checkpoint: Path, split: str = "test") -> None:
    # Create dataloaders (train, val, test)
    loaders = create_dataloaders(config)
    split_map = {"train": 0, "val": 1, "test": 2}
    if split not in split_map:
        raise ValueError("split must be one of 'train', 'val', or 'test'")
    loader = loaders[split_map[split]]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    num_classes = len(loader.dataset.label_to_index)
    model = CNNBaseline(num_classes=num_classes).to(device)
    model.load_state_dict(torch.load(checkpoint, map_location=device))
    model.eval()

    all_targets = []
    all_preds = []
    all_scores = []

    with torch.no_grad():
        for inputs, targets in loader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            probs = torch.softmax(outputs, dim=1)
            # For binary classification, take probability of class 1 as the score
            scores = probs[:, 1] if probs.shape[1] > 1 else probs[:, 0]
            preds = probs.argmax(dim=1).cpu().numpy()
            all_targets.extend(targets.tolist())
            all_preds.extend(preds.tolist())
            all_scores.extend(scores.cpu().tolist())

    acc, prec, rec, f1 = compute_basic_metrics(all_targets, all_preds)
    cm = compute_confusion(all_targets, all_preds)
    roc_auc = compute_roc_auc(all_targets, all_scores)

    print(f"Evaluation on {split} set:\n")
    print(f"Accuracy:  {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall:    {rec:.4f}")
    print(f"F1‑score:  {f1:.4f}")
    if roc_auc is not None:
        print(f"ROC‑AUC:   {roc_auc:.4f}")
    else:
        print("ROC‑AUC:   n/a (only one class present)")
    print("Confusion Matrix:\n", cm)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a trained model.")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/train.yaml",
        help="Path to YAML config used during training.",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        required=True,
        help="Path to the model checkpoint (*.pth).",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        choices=["train", "val", "test"],
        help="Which dataset split to evaluate.",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    evaluate_model(config, Path(args.checkpoint), split=args.split)


if __name__ == "__main__":
    main()
