"""FastAPI application for the medical AI prototype.

This service exposes a minimal API for running inference on medical
images using a trained model.  It is intended as a demo only and is
not a clinical device.  The API loads the model at startup and
responds to health checks and prediction requests.  All responses
include a disclaimer.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from PIL import Image
import torch

from ..models.cnn_baseline import CNNBaseline
from ..data.transforms import get_transforms
from ..models.infer import load_trained_model
from .schemas import PredictionResponse

# Define class names for binary classification.  In a real project
# these would come from the dataset metadata.  Adjust as needed.
CLASS_NAMES: List[str] = ["normal", "abnormal"]


def get_model() -> CNNBaseline:
    """Load the model checkpoint specified by the environment variable.

    Returns a CNN model instance loaded with weights from the given
    checkpoint.  Raises ``HTTPException`` if the file is missing.
    """
    checkpoint_path = os.getenv("MODEL_CHECKPOINT", "outputs/best_model.pth")
    checkpoint_file = Path(checkpoint_path)
    if not checkpoint_file.exists():
        raise HTTPException(
            status_code=500,
            detail=f"Model checkpoint not found at {checkpoint_path}. Please train the model first.",
        )
    model = load_trained_model(checkpoint_file, num_classes=len(CLASS_NAMES))
    return model


app = FastAPI(title="Medical AI Prototype API", version="0.1.0")


@app.on_event("startup")
def startup_event() -> None:
    # Load model into the application state at startup
    app.state.model = get_model()


@app.get("/health")
async def health() -> dict[str, str]:
    """Health check endpoint."""
    return {"status": "ok"}


@app.post("/predict", response_model=PredictionResponse)
async def predict(image: UploadFile = File(...)) -> PredictionResponse:
    """Predict the class of an uploaded image.

    Accepts a file upload and returns the predicted label and confidence.
    """
    # Validate file type
    if image.content_type not in {"image/png", "image/jpeg", "image/jpg"}:
        raise HTTPException(status_code=400, detail="Unsupported file type. Only PNG and JPEG images are accepted.")
    try:
        contents = await image.read()
        with Image.open(BytesIO(contents)) as img:
            img = img.convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid image file.")
    # Perform prediction
    transform = get_transforms("test", input_size=224)
    tensor = transform(img).unsqueeze(0)
    # Retrieve model from app state; lazily load if not present (e.g. during tests)
    model: CNNBaseline
    try:
        model = app.state.model  # type: ignore[assignment]
    except AttributeError:
        model = get_model()
        app.state.model = model  # cache for subsequent requests
    device = next(model.parameters()).device
    tensor = tensor.to(device)
    with torch.no_grad():
        outputs = model(tensor)
        probs = torch.softmax(outputs, dim=1).cpu().numpy()[0]
    pred_idx = int(probs.argmax())
    confidence = float(probs[pred_idx])
    prediction_label = CLASS_NAMES[pred_idx] if pred_idx < len(CLASS_NAMES) else str(pred_idx)
    return PredictionResponse(
        prediction=prediction_label,
        confidence=confidence,
        disclaimer="This prediction is for research use only and must not be used for clinical decision‑making.",
    )

from io import BytesIO  # keep import at bottom to avoid circular import issues
