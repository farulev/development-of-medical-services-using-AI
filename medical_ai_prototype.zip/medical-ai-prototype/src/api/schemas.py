"""Pydantic schemas for API requests and responses.

These classes define the structure of responses returned by the FastAPI
endpoints.  Using schemas ensures that the returned JSON matches
documentation and helps with validation.
"""

from __future__ import annotations

from pydantic import BaseModel


class PredictionResponse(BaseModel):
    prediction: str
    confidence: float
    disclaimer: str
