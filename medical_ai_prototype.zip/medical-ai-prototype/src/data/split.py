"""Dataset splitting utilities.

This module provides a function to split a metadata CSV into train,
validation and test subsets.  It writes out a new CSV with an
additional ``split`` column indicating the subset for each sample.
Splitting is done randomly but can be made reproducible via a
``random_seed`` parameter.
"""

from __future__ import annotations

import csv
import random
from pathlib import Path
from typing import Tuple


def split_metadata_csv(
    metadata_path: str | Path,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    random_seed: int | None = 42,
    output_path: str | Path | None = None,
) -> Path:
    """Split a metadata CSV into train/val/test and write a new CSV.

    Args:
        metadata_path: Path to the original metadata CSV without ``split`` column.
        train_ratio: Fraction of samples to assign to the training set.
        val_ratio: Fraction to assign to the validation set.
        test_ratio: Fraction to assign to the test set.
        random_seed: Seed for reproducible shuffling.
        output_path: Path where the split CSV will be written.  If None,
            the output file is saved next to the input with ``_split`` appended.

    Returns:
        The path to the new CSV file containing the ``split`` column.
    """
    metadata_path = Path(metadata_path)
    if output_path is None:
        output_path = metadata_path.with_name(metadata_path.stem + "_split.csv")
    output_path = Path(output_path)

    # Read all rows
    with metadata_path.open(newline="", encoding="utf-8") as f:
        reader = list(csv.DictReader(f))

    # Shuffle deterministically
    if random_seed is not None:
        random.seed(random_seed)
    random.shuffle(reader)

    total = len(reader)
    train_end = int(total * train_ratio)
    val_end = train_end + int(total * val_ratio)

    # Assign splits
    for i, row in enumerate(reader):
        if i < train_end:
            row["split"] = "train"
        elif i < val_end:
            row["split"] = "val"
        else:
            row["split"] = "test"

    # Determine fieldnames (ensure split column is last for readability)
    if reader:
        fieldnames = list(reader[0].keys())
    else:
        raise ValueError("Metadata CSV is empty; nothing to split.")

    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(reader)

    return output_path
