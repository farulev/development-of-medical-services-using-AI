"""Dataloader utilities for the medical AI prototype.

This module defines convenience functions for constructing PyTorch
``DataLoader`` objects for the training, validation and test splits.
Data loaders handle batching, shuffling and parallel loading.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Tuple

from torch.utils.data import DataLoader

from .dataset import MedicalDataset
from .transforms import get_transforms


def create_dataloaders(config: Dict[str, Any]) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """Create dataloaders for train/val/test splits based on a configuration dict.

    The configuration dictionary should have the following structure::

        {
          "dataset": {
            "metadata_csv": "path/to/metadata.csv",
            "images_root": "path/to/images",
            "num_workers": 0
          },
          "training": {
            "input_size": 224,
            "batch_size": 32
          }
        }

    Args:
        config: Nested configuration dictionary.

    Returns:
        A tuple of ``(train_loader, val_loader, test_loader)``.
    """
    dataset_cfg = config.get("dataset", {})
    train_cfg = config.get("training", {})
    metadata_csv = Path(dataset_cfg.get("metadata_csv", ""))
    images_root = Path(dataset_cfg.get("images_root", ""))
    num_workers = int(dataset_cfg.get("num_workers", 0))
    input_size = int(train_cfg.get("input_size", 224))
    batch_size = int(train_cfg.get("batch_size", 32))

    splits = ["train", "val", "test"]
    loaders = []
    for split in splits:
        ds = MedicalDataset(
            metadata_csv=metadata_csv,
            images_root=images_root,
            split=split,
            transform=get_transforms(split, input_size=input_size),
        )
        shuffle = split == "train"
        loader = DataLoader(
            ds,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=num_workers,
            pin_memory=False,
        )
        loaders.append(loader)
    return tuple(loaders)  # type: ignore[return-value]
