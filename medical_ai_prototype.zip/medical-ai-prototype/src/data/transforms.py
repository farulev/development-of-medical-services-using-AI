"""Custom image transformation utilities.

This module implements lightweight image transformations without
relying on ``torchvision``.  It defines a set of classes that can
resize images, apply random horizontal flips and rotations, convert
images to PyTorch tensors, and normalise them.  The primary goal is
to avoid optional dependencies that may not be available in minimal
environments while still providing basic augmentation capability.
"""

from __future__ import annotations

import random
from typing import Sequence, Tuple

import numpy as np
from PIL import Image, ImageOps
import torch


class Compose:
    """Compose several transforms together."""

    def __init__(self, transforms: Sequence) -> None:
        self.transforms = list(transforms)

    def __call__(self, img: Image.Image) -> torch.Tensor:
        for t in self.transforms:
            img = t(img)
        return img


class Resize:
    """Resize the input PIL Image to the given size (square)."""

    def __init__(self, size: int) -> None:
        self.size = size

    def __call__(self, img: Image.Image) -> Image.Image:
        return img.resize((self.size, self.size))


class RandomHorizontalFlip:
    """Horizontally flip the given PIL Image randomly with a given probability."""

    def __init__(self, p: float = 0.5) -> None:
        self.p = p

    def __call__(self, img: Image.Image) -> Image.Image:
        if random.random() < self.p:
            return ImageOps.mirror(img)
        return img


class RandomRotation:
    """Rotate the image by a random angle within the given range in degrees."""

    def __init__(self, degrees: float) -> None:
        self.degrees = degrees

    def __call__(self, img: Image.Image) -> Image.Image:
        angle = random.uniform(-self.degrees, self.degrees)
        return img.rotate(angle)


class ToTensor:
    """Convert a PIL Image to a torch.FloatTensor of shape (C, H, W) in [0, 1]."""

    def __call__(self, img: Image.Image) -> torch.Tensor:
        arr = np.asarray(img, dtype=np.float32) / 255.0  # shape (H, W, C)
        # Convert to (C, H, W)
        tensor = torch.from_numpy(arr.transpose((2, 0, 1)))
        return tensor


class Normalize:
    """Normalise a tensor image with mean and standard deviation."""

    def __init__(self, mean: Tuple[float, float, float], std: Tuple[float, float, float]) -> None:
        self.mean = torch.tensor(mean).view(-1, 1, 1)
        self.std = torch.tensor(std).view(-1, 1, 1)

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        return (tensor - self.mean) / self.std


IMAGENET_MEAN: Tuple[float, float, float] = (0.485, 0.456, 0.406)
IMAGENET_STD: Tuple[float, float, float] = (0.229, 0.224, 0.225)


def get_transforms(split: str, input_size: int) -> Compose:
    """Return a composed transform for the specified split.

    The training transform includes random horizontal flip and rotation,
    while the validation and test transforms perform deterministic resizing
    and normalisation only.
    """
    transforms_list = [Resize(input_size)]
    if split.lower() == "train":
        transforms_list.extend([
            RandomHorizontalFlip(),
            RandomRotation(degrees=10),
        ])
    transforms_list.extend([ToTensor(), Normalize(IMAGENET_MEAN, IMAGENET_STD)])
    return Compose(transforms_list)
