"""Dataset definitions for the medical AI prototype.

This module defines a simple ``MedicalDataset`` class that reads image
paths and labels from a CSV file.  The CSV is expected to have at least
four columns: ``image_path``, ``label``, ``patient_id`` and ``split``.
The ``split`` column should contain one of ``train``, ``val`` or ``test``
and is used to filter the dataset when instantiating the class.

The dataset does not assume the images have any specific size or
modality; they are loaded as RGB using Pillow and transformed via the
provided torchvision transform pipeline.

Labels are mapped to integer indices based on their sorted order.

Note: this dataset is designed for research and prototyping only.  It
expects synthetic or fully de‑identified data and should not be used on
real patient information without appropriate consent and compliance.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Callable, Dict, List, Tuple

from PIL import Image
from torch.utils.data import Dataset

LABEL_FIELD = "label"


class MedicalDataset(Dataset):
    """A PyTorch ``Dataset`` for medical images described by a CSV file.

    Args:
        metadata_csv: Path to the CSV file containing metadata.
        images_root: Base directory where image files reside.
        split: Which split to load (``train``, ``val`` or ``test``).
        transform: A callable/transform to apply to each image.
    """

    def __init__(
        self,
        metadata_csv: str | Path,
        images_root: str | Path,
        split: str,
        transform: Callable | None = None,
    ) -> None:
        self.metadata_path = Path(metadata_csv)
        self.images_root = Path(images_root)
        self.split = split
        self.transform = transform

        # Read metadata entries for the requested split
        self.entries: List[Tuple[Path, str]] = []
        with self.metadata_path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            if not {"image_path", "label", "split"}.issubset(reader.fieldnames or {}):
                raise ValueError(
                    f"Metadata CSV must contain 'image_path', 'label', and 'split' columns."
                )
            for row in reader:
                if row["split"].lower() != self.split.lower():
                    continue
                image_file = self.images_root / row["image_path"]
                label = row["label"]
                self.entries.append((image_file, label))

        # Build label to index mapping in deterministic order
        unique_labels = sorted({label for _, label in self.entries})
        self.label_to_index: Dict[str, int] = {lbl: idx for idx, lbl in enumerate(unique_labels)}

    def __len__(self) -> int:
        return len(self.entries)

    def __getitem__(self, index: int):
        image_path, label_name = self.entries[index]
        # Load image (convert to RGB regardless of original mode)
        with Image.open(image_path) as img:
            img = img.convert("RGB")
        if self.transform is not None:
            img = self.transform(img)
        label = self.label_to_index[label_name]
        return img, label
