"""Logging utilities.

This module defines a helper to obtain configured loggers.  All
loggers share the same basic configuration to ensure consistent
formatting across the application.  Logging levels can be set via
environment variables or passed explicitly to ``get_logger``.
"""

from __future__ import annotations

import logging
import os
from typing import Optional


def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """Get or create a logger with the given name.

    If the root logger has not been configured, this function sets up a
    basic configuration with a stream handler.  Log messages include
    the level name, logger name and message.  The logging level is
    taken from the ``level`` argument if provided, otherwise from the
    ``LOG_LEVEL`` environment variable or defaults to ``INFO``.

    Args:
        name: Name of the logger.
        level: Optional string level (e.g. 'debug', 'info').

    Returns:
        The configured logger.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        # Determine logging level
        level_name = level or os.getenv("LOG_LEVEL", "info")
        numeric_level = getattr(logging, level_name.upper(), logging.INFO)
        logger.setLevel(numeric_level)
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            fmt="[%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger
