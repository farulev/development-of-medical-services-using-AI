"""Reproducibility utilities.

Setting random seeds helps to make experiments deterministic.  This
module defines a helper function that sets seeds for Python's random
module, NumPy and PyTorch (both CPU and CUDA backends).  It also
configures PyTorch to use deterministic algorithms where possible.
"""

from __future__ import annotations

import os
import random
from typing import Optional

import numpy as np
import torch


def set_seed(seed: Optional[int] = None) -> None:
    """Set the seed for random number generators.

    Args:
        seed: An integer seed.  If None, a seed is derived from
            ``PYTHONHASHSEED`` or defaults to 0.
    """
    if seed is None:
        # derive from environment if available, else default
        seed_env = os.getenv("PYTHONHASHSEED")
        seed = int(seed_env) if seed_env is not None else 0
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Configure deterministic behaviour in PyTorch (may impact performance)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
