"""Path utilities.

Functions to assist with common filesystem operations, such as
creating directories if they do not exist.
"""

from __future__ import annotations

from pathlib import Path


def ensure_dir(path: str | Path) -> Path:
    """Create a directory if it doesn't already exist and return its path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
