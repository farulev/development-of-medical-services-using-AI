"""Configuration utilities.

Provides helper functions for loading YAML configuration files.  The
configuration is returned as a nested dictionary.  Additional logic
(such as merging with default values) can be added here in the future.
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Any, Dict


def load_config(config_path: str | Path) -> Dict[str, Any]:
    """Load a YAML configuration file into a dictionary.

    Args:
        config_path: Path to the YAML file.

    Returns:
        A nested dictionary representing the configuration.
    """
    path = Path(config_path)
    with path.open("r", encoding="utf-8") as f:
        config: Dict[str, Any] = yaml.safe_load(f)
    return config or {}
