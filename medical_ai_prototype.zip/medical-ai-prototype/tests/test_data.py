"""Tests for data loading utilities."""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np
from PIL import Image

# Add project root and src path to sys.path so that ``src`` can be imported
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
ROOT_PARENT = PROJECT_ROOT.parent
for p in [ROOT_PARENT, PROJECT_ROOT, SRC_PATH]:
    sp = str(p)
    if sp not in sys.path:
        sys.path.insert(0, sp)

from src.data.dataset import MedicalDataset
from src.data.transforms import get_transforms


def create_dummy_dataset(tmp_path: Path) -> Path:
    """Create a small synthetic dataset and return path to metadata CSV."""
    images_dir = tmp_path / "images"
    images_dir.mkdir()
    metadata_csv = tmp_path / "metadata.csv"
    # Create 4 random images and metadata entries
    rows = []
    for i in range(4):
        arr = (np.random.rand(224, 224, 3) * 255).astype(np.uint8)
        img_path = images_dir / f"img_{i}.png"
        Image.fromarray(arr).save(img_path)
        label = "normal" if i % 2 == 0 else "abnormal"
        split = "train" if i < 3 else "val"
        rows.append({"image_path": img_path.name, "label": label, "patient_id": str(i), "split": split})
    # Write CSV
    with metadata_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["image_path", "label", "patient_id", "split"])
        writer.writeheader()
        writer.writerows(rows)
    return metadata_csv


def test_medical_dataset_loading(tmp_path) -> None:
    # Create dummy dataset
    metadata_csv = create_dummy_dataset(tmp_path)
    dataset = MedicalDataset(
        metadata_csv=str(metadata_csv),
        images_root=metadata_csv.parent / "images",
        split="train",
        transform=get_transforms("train", 224),
    )
    # There should be 3 training samples
    assert len(dataset) == 3
    img, label = dataset[0]
    # Image tensor should have shape (3, 224, 224)
    assert img.shape == (3, 224, 224)
    # Label should be integer 0 or 1
    assert isinstance(label, int) and label in (0, 1)
