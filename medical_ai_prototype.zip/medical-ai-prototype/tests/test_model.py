"""Tests for model architecture."""

from __future__ import annotations

import sys
from pathlib import Path

import torch

# Add project root and src path to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
ROOT_PARENT = PROJECT_ROOT.parent
for p in [ROOT_PARENT, PROJECT_ROOT, SRC_PATH]:
    sp = str(p)
    if sp not in sys.path:
        sys.path.insert(0, sp)

from src.models.cnn_baseline import CNNBaseline


def test_cnn_baseline_forward() -> None:
    model = CNNBaseline(num_classes=2)
    model.eval()
    # Create a random input tensor (batch size 1)
    x = torch.randn(1, 3, 224, 224)
    with torch.no_grad():
        outputs = model(x)
    # Should output logits for 2 classes
    assert outputs.shape == (1, 2)
