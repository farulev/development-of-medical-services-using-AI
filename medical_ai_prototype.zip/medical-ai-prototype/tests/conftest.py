"""Pytest configuration file.

This file modifies the Python path so that the ``src`` package of the
medical AI prototype can be imported without installing the package.
Without this, tests executed via pytest will not find the ``src``
module because the current working directory may not include it in
``sys.path``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Add the project's ``src`` directory to sys.path
project_root = Path(__file__).resolve().parents[1]
src_path = project_root / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))
