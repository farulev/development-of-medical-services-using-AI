"""Tests for the FastAPI service."""

from __future__ import annotations

import os
import sys
from importlib import reload
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from fastapi.testclient import TestClient

# Add project root and src path to sys.path so that ``src`` can be imported
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
ROOT_PARENT = PROJECT_ROOT.parent
for p in [ROOT_PARENT, PROJECT_ROOT, SRC_PATH]:
    sp = str(p)
    if sp not in sys.path:
        sys.path.insert(0, sp)

from src.models.cnn_baseline import CNNBaseline


def create_dummy_checkpoint(tmp_path: Path) -> Path:
    # Create a model and save random weights
    model = CNNBaseline(num_classes=2)
    ckpt_path = tmp_path / "dummy_model.pth"
    torch.save(model.state_dict(), ckpt_path)
    return ckpt_path


def test_api_health_and_predict(tmp_path) -> None:
    # Prepare dummy checkpoint and set environment
    ckpt = create_dummy_checkpoint(tmp_path)
    os.environ["MODEL_CHECKPOINT"] = str(ckpt)
    # Reload the app module to pick up new env var
    import src.api.app as app_module
    reload(app_module)
    client = TestClient(app_module.app)

    # Test health endpoint
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json().get("status") == "ok"

    # Create dummy image
    arr = (np.random.rand(224, 224, 3) * 255).astype(np.uint8)
    img = Image.fromarray(arr)
    tmp_image_path = tmp_path / "tmp.png"
    img.save(tmp_image_path)

    with open(tmp_image_path, "rb") as f:
        files = {"image": ("tmp.png", f, "image/png")}
        resp = client.post("/predict", files=files)
    assert resp.status_code == 200
    data = resp.json()
    assert "prediction" in data
    assert "confidence" in data
    assert "disclaimer" in data
