"""Wrapper script to launch training from the command line."""

from __future__ import annotations

import argparse

from src.models.train import main as train_main


def main() -> None:
    parser = argparse.ArgumentParser(description="Run model training with a config file.")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/train.yaml",
        help="Path to YAML configuration for training.",
    )
    args = parser.parse_args()
    # Import here to avoid eager import of heavy libraries when help is requested
    from src.models.train import train_model
    from src.utils.config import load_config
    config = load_config(args.config)
    checkpoint_path = train_model(config)
    print(f"Training completed. Best model saved at: {checkpoint_path}")


if __name__ == "__main__":
    main()
