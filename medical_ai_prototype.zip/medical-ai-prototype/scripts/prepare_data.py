"""Utility script to generate a synthetic dataset.

This script creates a directory of randomly generated images and a
metadata CSV file suitable for testing the medical AI prototype.
Labels are assigned randomly between ``normal`` and ``abnormal`` and
splits (train/val/test) are assigned according to specified ratios.
Usage:

    python scripts/prepare_data.py --output-dir data/samples --num-samples 200
"""

from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path
from typing import List, Tuple

import numpy as np
from PIL import Image


def generate_image(size: int = 224) -> np.ndarray:
    """Generate a synthetic RGB image with random noise."""
    return (np.random.rand(size, size, 3) * 255).astype(np.uint8)


def write_dataset(
    output_dir: Path, num_samples: int, train_ratio: float = 0.7, val_ratio: float = 0.15
) -> None:
    images_dir = output_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)
    metadata_csv = output_dir / "metadata.csv"
    labels = ["normal", "abnormal"]

    rows: List[dict[str, str]] = []
    for i in range(num_samples):
        img_arr = generate_image()
        img_name = f"img_{i:04d}.png"
        img_path = images_dir / img_name
        Image.fromarray(img_arr).save(img_path)
        label = random.choice(labels)
        # assign splits based on index for reproducibility
        frac = i / num_samples
        if frac < train_ratio:
            split = "train"
        elif frac < train_ratio + val_ratio:
            split = "val"
        else:
            split = "test"
        rows.append(
            {
                "image_path": img_name,
                "label": label,
                "patient_id": str(i),
                "split": split,
            }
        )
    # Write metadata CSV
    with metadata_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["image_path", "label", "patient_id", "split"]
        )
        writer.writeheader()
        writer.writerows(rows)
    print(f"Synthetic dataset with {num_samples} samples created at {output_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a synthetic dataset of images and metadata.")
    parser.add_argument(
        "--output-dir",
        type=str,
        required=True,
        help="Directory where images and metadata.csv will be saved.",
    )
    parser.add_argument(
        "--num-samples",
        type=int,
        default=100,
        help="Number of samples to generate.",
    )
    args = parser.parse_args()
    output_dir = Path(args.output_dir)
    write_dataset(output_dir, args.num_samples)


if __name__ == "__main__":
    main()
