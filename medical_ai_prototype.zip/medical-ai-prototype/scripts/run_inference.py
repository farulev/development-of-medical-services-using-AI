"""Wrapper script to run inference on a single image."""

from __future__ import annotations

import argparse

from src.models.infer import main as infer_main


def main() -> None:
    parser = argparse.ArgumentParser(description="Run inference on a single image using a trained model.")
    parser.add_argument("--image", type=str, required=True, help="Path to the image file.")
    parser.add_argument(
        "--checkpoint", type=str, required=True, help="Path to the model checkpoint (*.pth)."
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/inference.yaml",
        help="Path to inference configuration file.",
    )
    args = parser.parse_args()
    # We pass through to the underlying infer.main, which will parse the same args again.
    infer_main()


if __name__ == "__main__":
    main()
