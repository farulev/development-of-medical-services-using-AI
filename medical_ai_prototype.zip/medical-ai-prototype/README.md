# AI‑Assisted Medical Image Classification & Triage

**Prototype repository — research only**

This project contains a minimal but realistic prototype for an AI‑assisted medical imaging system.  It demonstrates the full machine‑learning pipeline on a synthetic dataset: ingesting images and metadata, preprocessing and splitting the data, training a baseline convolutional neural network (CNN), evaluating its performance, performing inference on new images, and exposing the model via a simple API.  **This repository is **not** a clinical device and is not intended for patient care.  All data used or generated is synthetic or fully de‑identified, and no medical decisions should be based on this prototype.**

## Problem statement

Radiology workflows around the world suffer from a shortage of qualified specialists and increasing workload.  Reporting delays can lead to missed findings and poorer outcomes.  AI systems have the potential to improve triage by flagging abnormal studies for faster review.  However, building clinical‑grade AI models requires high‑quality data, careful validation and regulatory approval.  This prototype explores the technical aspects of such a system in a safe, research context.

## Scope of this prototype

The goal of this project is to provide engineers and researchers with a starting point for developing and experimenting with medical imaging models.  It implements:

* A synthetic or mock dataset loader with a simple CSV metadata format (`image_path,label,patient_id,split`).
* Data preprocessing utilities (image transforms, normalisation and train/validation/test splitting) that can be easily adapted to real datasets once de‑identified data becomes available.
* A baseline CNN classifier implemented in PyTorch for binary classification of chest X‑ray images (normal vs. abnormal).  The model code is modular, making it straightforward to swap in other architectures such as ResNet or EfficientNet.
* Training and evaluation scripts that support early stopping, checkpointing and standard metrics (accuracy, precision, recall, F1‑score, ROC‑AUC).
* An inference script for single‑image prediction that returns probabilities in a human‑readable JSON‑like format.
* A simple FastAPI web service with a health check and prediction endpoint accepting image uploads.  The API responds with the predicted class, confidence and a disclaimer.
* Documentation covering system architecture, risk and limitations, and a roadmap for future work.

## Architecture

At a high level the system follows this sequence:

1. **Data ingestion** – Synthetic or de‑identified images and a CSV metadata file are placed in the `data/` directory.  A script (`scripts/prepare_data.py`) can generate a toy dataset for experimentation.
2. **Preprocessing** – The data loader reads images, applies normalisation and augments the training set.  A utility splits the dataset into train, validation and test subsets without leakage.
3. **Model training** – A configurable training script (`scripts/run_training.py`) instantiates the CNN, loads data via the dataset class, runs the training loop with early stopping and logs metrics to the console.  The best model checkpoint is saved to `outputs/`.
4. **Evaluation** – The evaluation module computes metrics on the validation and test sets, including confusion matrix and ROC‑AUC where applicable.  Results are logged and saved.
5. **Inference** – A standalone script (`scripts/run_inference.py`) loads a saved checkpoint and runs the model on a single image, returning a JSON dictionary with predicted class and probability.
6. **API demo** – The FastAPI app (`src/api/app.py`) exposes `/health` and `/predict` endpoints.  The latter accepts a file upload and returns the model’s prediction along with a disclaimer.

This modular design allows you to replace individual components (e.g. model architecture or data loader) without rewriting the entire system.  Refer to `docs/architecture.md` for a more detailed component diagram.

## Quick start

### Installation

```bash
git clone <repository-url> medical-ai-prototype
cd medical-ai-prototype
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Alternatively, you can install the package in editable mode with `pip install -e .` after generating the `pyproject.toml` file.

### Preparing data

This prototype ships without real patient data.  To create a toy dataset of random images and labels for development, run:

```bash
python scripts/prepare_data.py --output-dir data/samples --num-samples 200
```

This will generate synthetic images and a `metadata.csv` file under `data/samples`.  In a real project you would replace this with de‑identified images and a corresponding CSV.

### Training a model

Specify your configuration in `configs/train.yaml` (see the default values in `configs/default.yaml`).  Then run:

```bash
python scripts/run_training.py --config configs/train.yaml
```

The script will train the model on the training set, evaluate on the validation set after each epoch, apply early stopping when the validation loss does not improve, and save the best checkpoint to `outputs/`.

### Evaluating the model

You can run evaluation separately by calling the evaluation module:

```bash
python -m src.models.evaluate --config configs/train.yaml --checkpoint outputs/best_model.pth
```

Metrics including accuracy, precision, recall, F1‑score and ROC‑AUC will be printed to the console.

### Inference on a new image

To perform inference on a single image using a saved model checkpoint:

```bash
python scripts/run_inference.py --image path/to/image.png --checkpoint outputs/best_model.pth
```

This will return a JSON object with the predicted class, probability and a disclaimer that the output is not a diagnosis.

### Starting the API

The FastAPI service depends on the trained model.  Ensure you have a checkpoint saved under `outputs/`.  Then run:

```bash
uvicorn src.api.app:app --reload --port 8000
```

You can check the service status at `http://localhost:8000/health`.  To make a prediction, send a `POST` request to `http://localhost:8000/predict` with a file field named `image`.  For example using `curl`:

```bash
curl -F "image=@/path/to/image.png" http://localhost:8000/predict
```

The API will return a JSON response like:

```json
{
  "prediction": "abnormal",
  "confidence": 0.87,
  "disclaimer": "This prediction is for research use only and must not be used for clinical decision‑making."
}
```

## Repository structure

```
medical-ai-prototype/
├── configs/                # YAML configuration files for training and inference
├── data/                   # Data directory (raw, processed and samples)
├── docs/                   # Additional documentation (architecture, roadmap, risks)
├── notebooks/              # Jupyter notebooks for exploration and demos
├── scripts/                # Command‑line helpers for data prep, training and inference
├── src/                    # Python package containing library code
│   ├── api/                # FastAPI service
│   ├── data/               # Data loading and preprocessing modules
│   ├── models/             # Model architectures and training logic
│   └── utils/              # Utility functions (config, logging, reproducibility)
├── tests/                  # Pytest test cases
├── .env.example            # Example environment variables file
├── .gitignore              # Standard git ignore rules
├── LICENSE                 # Open‑source license (MIT)
├── Makefile                # Convenience commands (linting, testing, etc.)
├── pyproject.toml          # Build configuration and dependencies
├── requirements.txt        # Basic pip requirements for quick installation
└── README.md               # This document
```

See the [docs/roadmap.md](docs/roadmap.md) file for planned enhancements such as DICOM support, advanced architectures, explainability methods and regulatory considerations.

## Disclaimers and limitations

This repository is provided for **research and educational purposes only**.  The data included is synthetic or de‑identified; the model has **not** been clinically validated; the API is **not** a medical device.  Use of this code or any derived products for clinical decision‑making without appropriate regulatory approval and validation is strictly prohibited.  See `docs/risk_and_limitations.md` for an in‑depth discussion of potential biases, overfitting, domain shift and regulatory gaps.
