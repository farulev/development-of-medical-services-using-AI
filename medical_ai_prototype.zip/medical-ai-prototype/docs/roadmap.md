# Roadmap

This roadmap outlines planned extensions and improvements for the medical AI prototype.  It is aspirational and may change as the project evolves.

## Short‑term (next 3–6 months)

* **DICOM support** – Replace the PNG/JPEG loaders with a reader for DICOM files (e.g. using `pydicom`) and extract metadata such as modality, acquisition parameters and patient information (appropriately de‑identified).  Update the dataset classes to handle multi‑slice volumes where applicable.
* **Model architectures** – Add support for pre‑trained architectures (ResNet, DenseNet, EfficientNet) and fine‑tune them on medical images.  Provide a mechanism to select the architecture via configuration.
* **Enhanced data augmentation** – Incorporate domain‑specific augmentations such as intensity scaling, noise injection and random cropping to improve generalisation.
* **Command‑line improvements** – Add options for learning rate schedulers, mixed‑precision training and configurable optimisers.
* **Dockerisation** – Provide a Dockerfile and docker‑compose configuration to simplify environment setup and deployment.

## Medium‑term (6–12 months)

* **Explainability** – Integrate techniques such as Grad‑CAM or integrated gradients to visualise salient regions of images that contribute to the model’s predictions.  Expose these visualisations via the API.
* **Model registry** – Implement a lightweight model registry to keep track of trained models, their configurations, metrics and provenance.  Provide utilities to load specific versions.
* **Streaming inference** – Optimise inference for real‑time clinical workflows, including batching requests and using hardware acceleration where available.
* **Comprehensive testing** – Expand the test suite to include integration tests for training, evaluation and API endpoints under various scenarios.
* **Continuous integration (CI)** – Add workflows (e.g. GitHub Actions) to run linting, testing and build steps automatically on pull requests.

## Long‑term (>12 months)

* **Clinical datasets** – Partner with healthcare institutions to obtain de‑identified clinical datasets with expert annotations.  Implement data governance practices to ensure compliance with privacy regulations.
* **Multi‑modal learning** – Extend the framework to combine images with clinical text (reports, laboratory values) using transformer architectures.  Explore fusion techniques.
* **Performance monitoring** – Develop tools to monitor model performance in production, detect drift and trigger retraining when necessary.
* **Regulatory pathway** – Engage with regulatory agencies to understand approval requirements and design studies that could support submission.  Implement software quality management practices aligned with IEC 62304.

This roadmap is intentionally ambitious.  Contributions from the community are welcome to help realise these goals.  Please refer to the [CONTRIBUTING](../CONTRIBUTING.md) guidelines (to be created) for information on how to get involved.