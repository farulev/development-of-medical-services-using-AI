# System Architecture

This document describes the high‑level architecture of the medical AI prototype.  The prototype is organised into distinct modules to support modularity, reproducibility and ease of experimentation.

## Components

### Data layer

* **Dataset definitions** (`src/data/dataset.py`)
  – implements `MedicalDataset`, a PyTorch dataset class that reads image paths and labels from a CSV file.  It filters samples by the `split` column and applies torchvision transforms on the fly.

* **Transforms** (`src/data/transforms.py`)
  – factory functions for constructing augmentation and normalisation pipelines for each split (train/val/test).  They resize images, apply optional augmentations and convert to tensors.

* **Dataloaders** (`src/data/loaders.py`)
  – convenience function to build `DataLoader` objects for each split based on a configuration dictionary.  It instantiates datasets and wraps them in PyTorch dataloaders with appropriate shuffling and batching.

* **Dataset splitting utility** (`src/data/split.py`)
  – optional helper to split a metadata CSV into train, validation and test subsets.  This is used when working with real datasets that don’t already include split annotations.

### Model layer

* **Model architectures** (`src/models/cnn_baseline.py`)
  – defines a simple convolutional neural network (CNN) for binary classification.  The architecture consists of three convolutional blocks followed by fully connected layers.  The number of output classes is configurable.

* **Metrics** (`src/models/metrics.py`)
  – wraps common metrics from scikit‑learn (accuracy, precision, recall, F1, ROC‑AUC, confusion matrix) and handles edge cases where metrics cannot be computed.

* **Training** (`src/models/train.py`)
  – implements the training loop with early stopping and checkpoint saving.  Reads hyperparameters and paths from a YAML configuration file.  Logs training and validation loss at configurable intervals.

* **Evaluation** (`src/models/evaluate.py`)
  – loads a saved model checkpoint and computes evaluation metrics on a specified dataset split.  Prints results to the console.

* **Inference** (`src/models/infer.py`)
  – provides functions to load a trained model and run inference on a single image, returning predictions and confidence scores in a JSON‑like structure.

### API layer

* **FastAPI service** (`src/api/app.py`)
  – exposes two endpoints: `/health` for service monitoring and `/predict` for uploading an image and receiving a prediction.  The service loads a model checkpoint at startup (path specified via the `MODEL_CHECKPOINT` environment variable) and performs inference on uploaded images.  The API responds with the predicted class, confidence and a research‑use‑only disclaimer.

* **Schemas** (`src/api/schemas.py`)
  – defines Pydantic models for responses to ensure consistent output structure and automatic API documentation.

### Utility layer

* **Config loader** (`src/utils/config.py`)
  – loads YAML files into Python dictionaries.  Intended to be extended with default merging logic if desired.

* **Logging** (`src/utils/logging.py`)
  – provides a `get_logger` function that configures loggers with a consistent format and respects environment‑driven log level.

* **Seeding** (`src/utils/seed.py`)
  – sets random seeds for Python, NumPy and PyTorch and activates deterministic modes for reproducibility.

* **Paths** (`src/utils/paths.py`)
  – helper for ensuring directories exist.

### Command‑line scripts

* **Data generation** (`scripts/prepare_data.py`)
  – creates a synthetic dataset of random images and a `metadata.csv` file.  Useful for testing and development without access to real data.

* **Training wrapper** (`scripts/run_training.py`)
  – loads a configuration file, constructs dataloaders and trains the model, saving the best checkpoint.

* **Inference wrapper** (`scripts/run_inference.py`)
  – runs inference on a single image using a trained model and prints a JSON string with the results.

## Data flow

1. **Data preparation**: Raw or synthetic images and metadata are placed in `data/`.  For development, the `prepare_data.py` script can generate synthetic images and a CSV with `image_path`, `label`, `patient_id` and `split` columns.
2. **Training**: `run_training.py` reads a YAML configuration file, constructs dataloaders via `create_dataloaders`, instantiates the CNN model, and runs the training loop.  Early stopping monitors validation loss and the best model is saved under `outputs/`.
3. **Evaluation**: `evaluate.py` loads the saved checkpoint and computes metrics on the validation or test set, reporting them in a human‑readable format.
4. **Inference**: `run_inference.py` or the FastAPI service loads the model and runs prediction on new images, returning class labels and confidence scores.  The API is suitable for demonstrating integration with other systems.

## Extensibility

The codebase is designed to be modular so that individual components can be replaced or extended.  For example:

* To improve performance, swap `CNNBaseline` for a deeper architecture in `src/models/cnn_baseline.py` or add a new model file.
* To support multi‑class classification, update the number of output classes and adjust `CLASS_NAMES` in `src/api/app.py`.
* To work with real datasets, replace the synthetic data generator with code that reads de‑identified images and metadata.  Use `src/data/split.py` to create train/val/test splits.
* To experiment with additional metrics or logging tools, extend the modules in `src/models/metrics.py` and `src/utils/logging.py`.

Refer to the [README](../README.md) for instructions on how to run each component.