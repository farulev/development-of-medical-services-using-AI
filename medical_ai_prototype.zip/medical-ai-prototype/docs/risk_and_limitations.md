# Risks and Limitations

This document outlines some of the inherent risks and limitations associated with AI models in medical imaging.  Understanding these issues is essential for responsible development and deployment.

## Data bias and representativeness

* **Bias in training data** – If the dataset used to train the model does not reflect the diversity of the patient population, the model may exhibit systematic errors on under‑represented groups.  For example, imaging equipment, protocols, patient demographics and comorbidities vary across institutions and regions.
* **Synthetic data** – The synthetic data provided with this prototype does not reflect real imaging distributions.  It should only be used to test the pipeline; performance on synthetic data does not translate to clinical utility.

## Overfitting and generalisation

* **Overfitting** – With limited data, models may memorise training examples rather than learning generalizable patterns.  The prototype includes early stopping, but thorough evaluation on independent data is necessary.
* **Domain shift** – Models trained on one hospital’s data may perform poorly on images from another hospital due to differences in scanners, protocols or population health.  External validation on multiple institutions is critical before any clinical use.

## Validation and clinical performance

* **Lack of clinical validation** – This prototype has not been tested on real medical images.  No claims are made about diagnostic accuracy or safety.  Without rigorous clinical validation, the model should not be used to inform patient care.
* **Performance metrics** – Accuracy, precision and recall provide a limited view of model performance.  Clinically meaningful evaluation should include sensitivity, specificity, positive/negative predictive value and decision‑curve analysis in the intended use case.

## Regulatory and ethical considerations

* **Regulatory compliance** – Medical AI systems deployed in practice require approval from regulators (e.g. FDA, EMA, local Ministries of Health).  This prototype does not meet any regulatory requirements.
* **Privacy and security** – Handling of real patient data requires strict compliance with privacy laws (e.g. HIPAA, GDPR).  The prototype only uses synthetic data but any extension must ensure proper anonymisation and secure storage.
* **Clinical responsibility** – AI tools should augment, not replace, qualified clinicians.  Even high‑performing models can make errors.  Decision‑making responsibility rests with healthcare professionals.

## Future work needed

To mitigate these risks and move toward safe and effective clinical applications, future work should focus on:

* Collecting large, diverse and de‑identified datasets with high‑quality annotations.
* Performing external validation across multiple institutions and imaging devices.
* Developing methods to detect out‑of‑distribution inputs and monitor model drift over time.
* Incorporating explainability techniques to increase clinician trust and facilitate error analysis.
* Engaging with regulatory bodies early in development to ensure compliance with applicable standards.

This list is not exhaustive; as the field evolves, new risks and mitigation strategies will emerge.  Developers and researchers should remain vigilant and follow best practices for medical AI.